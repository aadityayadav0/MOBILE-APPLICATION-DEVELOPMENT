import streamlit.components.v1 as components

def voice_input_html():
    html = """
    <div style="font-family:Arial;padding:10px;border:1px solid #ddd;border-radius:12px">
      <button id="start" style="padding:10px 16px;border:0;border-radius:8px;background:#0aa;color:white">
        🎙️ Start Listening
      </button>
      <button id="stop" style="padding:10px 16px;border:0;border-radius:8px">
        Stop
      </button>
      <p><b>Transcript:</b></p>
      <textarea id="out" rows="4" style="width:100%;font-size:16px"
        placeholder="Hindi speech transcript यहाँ दिखाई देगा"></textarea>
      <p style="font-size:13px;color:#666">
        Browser में Hindi speech recognition support होने पर यह काम करेगा.
        Transcript को copy करके app के symptom box में paste करें.
      </p>
      <script>
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const out = document.getElementById("out");
        const start = document.getElementById("start");
        const stop = document.getElementById("stop");

        if (!SpeechRecognition) {
          out.value = "इस browser में speech recognition उपलब्ध नहीं है. Chrome में try करें.";
        } else {
          const rec = new SpeechRecognition();
          rec.lang = "hi-IN";
          rec.continuous = true;
          rec.interimResults = true;

          start.onclick = () => rec.start();
          stop.onclick = () => rec.stop();

          rec.onresult = (event) => {
            let finalText = "";
            let interim = "";
            for (let i = event.resultIndex; i < event.results.length; i++) {
              const text = event.results[i][0].transcript;
              if (event.results[i].isFinal) finalText += text + " ";
              else interim += text;
            }
            out.value = (out.value + " " + finalText + interim).trim();
          };
        }
      </script>
    </div>
    """
    components.html(html, height=260)

def speak_result_html(text):
    safe = (text or "").replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
    html = f"""
    <button onclick="speechSynthesis.cancel(); speechSynthesis.speak(
      new SpeechSynthesisUtterance('{safe}')
    )" style="padding:10px 16px;border:0;border-radius:8px;background:#0aa;color:white">
      🔊 Hindi में Result सुनें
    </button>
    """
    components.html(html, height=60)
