import re

# Hindi/English phrases mapped to normalized symptom names.
KEYWORDS = {
    "fever": ["बुखार", "fever", "bukhar", "ताप", "temperature"],
    "cough": ["खांसी", "cough", "khansi"],
    "sore_throat": ["गले में दर्द", "गला दर्द", "sore throat", "throat pain"],
    "headache": ["सिर दर्द", "सर दर्द", "headache", "sar dard"],
    "runny_nose": ["नाक बहना", "जुकाम", "runny nose", "cold", "naak bahna"],
    "body_ache": ["शरीर दर्द", "body ache", "body pain", "badan dard"],
    "fatigue": ["थकान", "कमजोरी", "fatigue", "weakness"],
    "nausea": ["मतली", "जी मिचलाना", "nausea"],
    "vomiting": ["उल्टी", "vomiting", "ulti"],
    "diarrhea": ["दस्त", "loose motion", "diarrhea", "dast"],
    "stomach_pain": ["पेट दर्द", "stomach pain", "pet dard"],
    "chest_pain": ["सीने में दर्द", "छाती में दर्द", "chest pain", "seene mein dard"],
    "breathing": ["सांस फूलना", "सांस लेने में दिक्कत", "breathing difficulty", "shortness of breath", "saans"],
    "dizziness": ["चक्कर", "dizziness", "chakkar"],
    "rash": ["दाने", "खुजली", "rash", "itching"],
    "back_pain": ["कमर दर्द", "पीठ दर्द", "back pain"],
    "joint_pain": ["जोड़ों का दर्द", "joint pain", "joints pain"],
    "burn": ["जलना", "burn", "जल गया"],
    "injury": ["चोट", "injury", "घायल"],
}

SYMPTOM_LABELS = {
    "fever": "बुखार / Fever",
    "cough": "खांसी / Cough",
    "sore_throat": "गले में दर्द / Sore throat",
    "headache": "सिर दर्द / Headache",
    "runny_nose": "नाक बहना / Cold",
    "body_ache": "शरीर दर्द / Body ache",
    "fatigue": "थकान / Fatigue",
    "nausea": "मतली / Nausea",
    "vomiting": "उल्टी / Vomiting",
    "diarrhea": "दस्त / Diarrhea",
    "stomach_pain": "पेट दर्द / Stomach pain",
    "chest_pain": "सीने में दर्द / Chest pain",
    "breathing": "सांस में दिक्कत / Breathing difficulty",
    "dizziness": "चक्कर / Dizziness",
    "rash": "दाने/खुजली / Rash",
    "back_pain": "कमर/पीठ दर्द / Back pain",
    "joint_pain": "जोड़ों का दर्द / Joint pain",
    "burn": "जलना / Burn",
    "injury": "चोट / Injury",
}

def normalize_hindi_text(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower().strip())

def detect(text):
    t = normalize_hindi_text(text)
    found = []
    for key, words in KEYWORDS.items():
        if any(w.lower() in t for w in words):
            found.append(key)
    return found

def analyze_symptoms(text, selected_labels):
    found = set(detect(text))

    reverse = {v: k for k, v in SYMPTOM_LABELS.items()}
    for label in selected_labels:
        if label in reverse:
            found.add(reverse[label])

    # Safety-first triage rules. These are screening rules, not diagnosis.
    if {"chest_pain", "breathing"} & found:
        urgency = "Emergency"
        condition = "Urgent cardiopulmonary symptoms"
        advice = "सीने में दर्द या सांस की गंभीर दिक्कत को घर पर diagnose न करें; तुरंत medical evaluation लें."
        hindi_voice = "आपके बताए लक्षणों में सीने में दर्द या सांस की दिक्कत शामिल है। तुरंत चिकित्सकीय सहायता लें।"
    elif "breathing" in found:
        urgency = "Emergency"
        condition = "Breathing-related warning"
        advice = "सांस लेने में गंभीर कठिनाई हो तो तुरंत emergency medical help लें."
        hindi_voice = "सांस लेने में दिक्कत है। अगर यह गंभीर है या बढ़ रही है तो तुरंत चिकित्सा सहायता लें।"
    elif "injury" in found or "burn" in found:
        urgency = "Doctor soon"
        condition = "Injury / burn"
        advice = "चोट या जलने की गंभीरता के अनुसार clinician से assessment कराएँ."
        hindi_voice = "चोट या जलने के लक्षण हैं। अगर चोट गंभीर है तो डॉक्टर से जल्द संपर्क करें।"
    elif {"fever", "cough", "sore_throat"} <= found:
        urgency = "Doctor soon"
        condition = "Respiratory infection-like symptom group"
        advice = "यह केवल symptom grouping है; persistent/high fever, worsening cough या breathing difficulty में clinician से सलाह लें."
        hindi_voice = "बुखार, खांसी और गले में दर्द हैं। अगर लक्षण बढ़ें या बने रहें तो डॉक्टर से सलाह लें।"
    elif {"vomiting", "diarrhea"} & found:
        urgency = "Doctor soon"
        condition = "Gastrointestinal symptom group"
        advice = "Fluids पर ध्यान दें; dehydration, blood, severe pain या persistent symptoms में medical care लें."
        hindi_voice = "पेट से जुड़े लक्षण हैं। पानी की कमी के संकेत या लगातार लक्षण हों तो डॉक्टर से सलाह लें।"
    elif {"headache", "fever"} <= found:
        urgency = "Doctor soon"
        condition = "Fever + headache symptom group"
        advice = "आराम और fluids रखें; severe/persistent symptoms में clinician से सलाह लें."
        hindi_voice = "बुखार और सिर दर्द हैं। लक्षण गंभीर या लगातार हों तो डॉक्टर से सलाह लें।"
    elif found:
        urgency = "Monitor"
        condition = "General symptom group"
        advice = "Symptoms monitor करें. अगर लक्षण लगातार रहें, बढ़ें या नए गंभीर लक्षण आएँ तो clinician से संपर्क करें."
        hindi_voice = "कुछ सामान्य लक्षण मिले हैं। आराम करें, लक्षणों को monitor करें और जरूरत पड़ने पर डॉक्टर से सलाह लें।"
    else:
        urgency = "Monitor"
        condition = "No clear symptom match"
        advice = "Input में supported symptom phrase नहीं मिली. Symptoms को स्पष्ट शब्दों में दोबारा लिखें."
        hindi_voice = "कोई स्पष्ट supported symptom match नहीं मिला। कृपया अपने लक्षण दोबारा स्पष्ट लिखें।"

    labels = [SYMPTOM_LABELS[x] for x in sorted(found)]
    return {
        "matched": labels,
        "condition": condition,
        "urgency": urgency,
        "advice": advice,
        "hindi_voice": hindi_voice,
    }
