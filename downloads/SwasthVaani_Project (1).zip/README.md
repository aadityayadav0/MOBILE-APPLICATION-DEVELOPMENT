# SwasthVaani 🩺

Hindi voice-assisted health symptom screening project for a college demonstration.

## Important
This project is an educational screening/demo tool. It does not diagnose disease and should not replace a doctor.

## Features
- Hindi/English symptom text input
- Browser-based Hindi voice-to-text demo
- Symptom keyword mapping
- Safety-first triage rules
- Hindi voice output using browser speech synthesis
- SQLite patient/session history
- Nearby hospital search through Google Maps
- Streamlit web UI

## 1. Install Python
Install Python 3.10+.

## 2. Create environment
```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS/Termux:
```bash
source venv/bin/activate
```

## 3. Install packages
```bash
pip install -r requirements.txt
```

## 4. Run
```bash
streamlit run app.py
```

Then open the URL shown by Streamlit, usually:
http://localhost:8501

## 5. Mobile
On Android, you can use Termux + Python + Streamlit. The browser opens the Streamlit page. For the easiest college demonstration, running it on a PC/laptop is recommended.

## Project structure
```text
SwasthVaani/
├── app.py
├── symptom_engine.py
├── voice_ui.py
├── requirements.txt
├── README.md
└── data/
```

## Future upgrades
1. Replace keyword rules with a properly validated ML model.
2. Add a clinically reviewed symptom dataset.
3. Add authentication and encrypted storage.
4. Add a verified hospital/ambulance API.
5. Add a Flutter mobile frontend.
6. Add Vosk/Whisper as an optional server-side speech-to-text layer.
