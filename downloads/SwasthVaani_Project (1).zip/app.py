import streamlit as st
import sqlite3
from datetime import datetime
from symptom_engine import analyze_symptoms, normalize_hindi_text, SYMPTOM_LABELS
from voice_ui import voice_input_html, speak_result_html

st.set_page_config(page_title="SwasthVaani", page_icon="🩺", layout="centered")

DB = "swasthvaani.db"

def init_db():
    con = sqlite3.connect(DB)
    con.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT,
            user_text TEXT,
            symptoms TEXT,
            result TEXT,
            urgency TEXT
        )
    """)
    con.commit()
    con.close()

def save_history(user_text, symptoms, result, urgency):
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT INTO history(created_at,user_text,symptoms,result,urgency) VALUES(?,?,?,?,?)",
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
         user_text, ", ".join(symptoms), result, urgency)
    )
    con.commit()
    con.close()

def get_history():
    con = sqlite3.connect(DB)
    rows = con.execute(
        "SELECT created_at, symptoms, result, urgency FROM history ORDER BY id DESC LIMIT 20"
    ).fetchall()
    con.close()
    return rows

init_db()

st.title("🩺 SwasthVaani")
st.caption("Hindi Voice-Based Health Guidance & Screening Demo")

st.info(
    "यह educational screening project है। यह medical diagnosis नहीं करता। "
    "गंभीर या तेजी से बिगड़ते लक्षणों में तुरंत स्थानीय emergency service/doctor से संपर्क करें।"
)

with st.sidebar:
    st.header("👤 User")
    name = st.text_input("Name", "Aaditya Yadav")
    st.write("**Project:** SwasthVaani")
    st.write("**Mode:** Hindi symptom screening")
    st.divider()
    st.write("Use the app as a college-project demonstration, not as a substitute for a clinician.")

st.subheader("🎙️ Step 1 — Hindi Voice Input")
st.markdown("Chrome/Android में **Start Listening** दबाएँ, Hindi में बोलें, फिर transcript को copy करके नीचे paste करें.")
voice_input_html()

st.subheader("✍️ Step 2 — Describe Symptoms")
text = st.text_area(
    "अपने symptoms Hindi या simple English में लिखें",
    placeholder="जैसे: मुझे बुखार, खांसी और गले में दर्द है",
    height=120
)

st.subheader("☑️ Step 3 — Select Symptoms")
selected = st.multiselect(
    "Symptoms",
    options=list(SYMPTOM_LABELS.values()),
    format_func=lambda x: x
)

if st.button("🔎 Analyze Symptoms", type="primary", use_container_width=True):
    if not text.strip() and not selected:
        st.warning("कम से कम एक symptom लिखें या select करें.")
    else:
        result = analyze_symptoms(text, selected)
        save_history(text, result["matched"], result["condition"], result["urgency"])

        st.subheader("📋 Screening Result")
        st.write(f"**Matched symptoms:** {', '.join(result['matched']) if result['matched'] else 'None'}")
        st.write(f"**Possible category:** {result['condition']}")
        st.write(f"**Guidance level:** {result['urgency']}")
        st.write(f"**Guidance:** {result['advice']}")

        if result["urgency"] == "Emergency":
            st.error("🚨 Emergency warning: सांस लेने में बहुत कठिनाई, बेहोशी, severe chest pain या अन्य गंभीर स्थिति हो तो तुरंत emergency medical help लें.")
        elif result["urgency"] == "Doctor soon":
            st.warning("⚠️ Symptoms persistent/severe हों या हालत बिगड़े तो डॉक्टर से जल्द संपर्क करें.")
        else:
            st.success("ℹ️ Mild screening result. Rest, fluids और monitoring जैसे सामान्य self-care steps पर ध्यान दें; symptoms बने रहें तो clinician से सलाह लें.")

        speak_result_html(result["hindi_voice"])

st.subheader("📍 Nearby Hospital / Clinic Search")
city = st.text_input("अपना city/area लिखें", placeholder="Agra")
if city:
    import urllib.parse
    q = urllib.parse.quote(f"hospital near {city}")
    st.markdown(f"[Google Maps पर hospitals खोजें](https://www.google.com/maps/search/?api=1&query={q})")

st.subheader("🗂️ Saved History")
rows = get_history()
if rows:
    for created, symptoms, condition, urgency in rows:
        with st.expander(f"{created} — {urgency}"):
            st.write("**Symptoms:**", symptoms or "None")
            st.write("**Category:**", condition)
else:
    st.caption("अभी कोई history saved नहीं है.")
